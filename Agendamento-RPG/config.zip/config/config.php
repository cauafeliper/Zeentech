<?php 
    $dbHost = 'Localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'rpg';

    $conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);