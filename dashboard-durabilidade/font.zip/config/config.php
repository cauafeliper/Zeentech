<?php 
    $dbHost = 'Localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'zeentech';

    $conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
?>